import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, StyleSheet, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { auth, db } from './firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile } from 'firebase/auth';
import { collection, addDoc, onSnapshot, orderBy, query, serverTimestamp, doc, setDoc } from 'firebase/firestore';

function AuthScreen() {
  const [mode, setMode] = useState('login'); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [name,setName]=useState(''); const [busy,setBusy]=useState(false);
  async function submit(){
    if(!email.trim()||!password||(mode==='register'&&!name.trim())) return Alert.alert('Missing information','Please complete all fields.');
    setBusy(true);
    try{
      if(mode==='register'){
        const r=await createUserWithEmailAndPassword(auth,email.trim(),password);
        await updateProfile(r.user,{displayName:name.trim()});
        await setDoc(doc(db,'users',r.user.uid),{uid:r.user.uid,name:name.trim(),email:email.trim(),createdAt:serverTimestamp()});
      } else await signInWithEmailAndPassword(auth,email.trim(),password);
    }catch(e){Alert.alert('Could not continue',e.message)}finally{setBusy(false)}
  }
  return <SafeAreaView style={s.auth}><StatusBar style="light"/><View style={s.logo}><Text style={s.logoT}>C</Text></View><Text style={s.title}>ChatWave</Text><Text style={s.sub}>{mode==='login'?'Welcome back':'Create your account'}</Text>
    {mode==='register'&&<TextInput style={s.input} placeholder="Your name" value={name} onChangeText={setName}/>}<TextInput style={s.input} placeholder="Email" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail}/><TextInput style={s.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword}/>
    <TouchableOpacity style={s.primary} onPress={submit} disabled={busy}><Text style={s.primaryT}>{busy?'Please wait...':mode==='login'?'Log in':'Register'}</Text></TouchableOpacity><TouchableOpacity onPress={()=>setMode(mode==='login'?'register':'login')}><Text style={s.switch}>{mode==='login'?'New here? Create an account':'Already have an account? Log in'}</Text></TouchableOpacity></SafeAreaView>
}
function ChatScreen({user}){
  const [text,setText]=useState(''); const [messages,setMessages]=useState([]);
  useEffect(()=>{const q=query(collection(db,'messages'),orderBy('createdAt','asc'));return onSnapshot(q,snap=>setMessages(snap.docs.map(d=>({id:d.id,...d.data()}))),e=>Alert.alert('Chat error',e.message));},[]);
  async function send(){const v=text.trim();if(!v)return;setText('');try{await addDoc(collection(db,'messages'),{text:v,senderId:user.uid,senderName:user.displayName||user.email,createdAt:serverTimestamp()});}catch(e){setText(v);Alert.alert('Message failed',e.message)}}
  return <SafeAreaView style={s.chat}><StatusBar style="light"/><View style={s.header}><View style={s.avatar}><Text style={s.avatarT}>C</Text></View><View style={{flex:1}}><Text style={s.headerT}>ChatWave</Text><Text style={s.headerS}>Community chat</Text></View><TouchableOpacity onPress={()=>signOut(auth)}><Text style={s.logout}>Log out</Text></TouchableOpacity></View>
    <FlatList data={messages} keyExtractor={i=>i.id} contentContainerStyle={s.messages} renderItem={({item})=>{const mine=item.senderId===user.uid;return <View style={[s.bubble,mine?s.mine:s.theirs]}>{!mine&&<Text style={s.sender}>{item.senderName}</Text>}<Text style={s.msg}>{item.text}</Text></View>}}/>
    <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined}><View style={s.composer}><TextInput style={s.msgInput} placeholder="Type a message" value={text} onChangeText={setText} multiline/><TouchableOpacity style={s.send} onPress={send}><Text style={s.sendT}>➤</Text></TouchableOpacity></View></KeyboardAvoidingView></SafeAreaView>
}
export default function App(){const[user,setUser]=useState(undefined);useEffect(()=>onAuthStateChanged(auth,setUser),[]);if(user===undefined)return null;return user?<ChatScreen user={user}/>:<AuthScreen/>}
const s=StyleSheet.create({auth:{flex:1,backgroundColor:'#075E54',alignItems:'center',justifyContent:'center',padding:24},logo:{width:84,height:84,borderRadius:42,backgroundColor:'#25D366',alignItems:'center',justifyContent:'center',marginBottom:12},logoT:{color:'#fff',fontSize:42,fontWeight:'800'},title:{color:'#fff',fontSize:32,fontWeight:'800'},sub:{color:'#d8f5ef',marginBottom:28,marginTop:5},input:{width:'100%',backgroundColor:'#fff',borderRadius:12,padding:15,marginBottom:12,fontSize:16},primary:{width:'100%',backgroundColor:'#25D366',padding:16,borderRadius:12,alignItems:'center'},primaryT:{color:'#fff',fontWeight:'800',fontSize:16},switch:{color:'#fff',marginTop:20,fontWeight:'600'},chat:{flex:1,backgroundColor:'#ECE5DD'},header:{height:68,backgroundColor:'#075E54',flexDirection:'row',alignItems:'center',paddingHorizontal:12},avatar:{width:44,height:44,borderRadius:22,backgroundColor:'#25D366',alignItems:'center',justifyContent:'center',marginRight:10},avatarT:{color:'#fff',fontWeight:'800',fontSize:22},headerT:{color:'#fff',fontSize:18,fontWeight:'800'},headerS:{color:'#d8f5ef',fontSize:12},logout:{color:'#fff',fontSize:12,fontWeight:'700'},messages:{padding:10,paddingBottom:14},bubble:{maxWidth:'78%',paddingHorizontal:12,paddingVertical:8,borderRadius:12,marginVertical:4},mine:{alignSelf:'flex-end',backgroundColor:'#DCF8C6'},theirs:{alignSelf:'flex-start',backgroundColor:'#fff'},sender:{fontSize:11,fontWeight:'800',marginBottom:3,color:'#075E54'},msg:{fontSize:16,color:'#222'},composer:{flexDirection:'row',alignItems:'flex-end',padding:8,backgroundColor:'#f0f0f0'},msgInput:{flex:1,backgroundColor:'#fff',borderRadius:22,paddingHorizontal:16,paddingVertical:10,maxHeight:110,fontSize:16},send:{width:46,height:46,borderRadius:23,backgroundColor:'#25D366',alignItems:'center',justifyContent:'center',marginLeft:7},sendT:{color:'#fff',fontSize:24}}
);
