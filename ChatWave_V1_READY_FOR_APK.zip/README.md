# ChatWave V1

Real Android app source for a WhatsApp-style starter messenger.

## Current features
- Email/password registration
- Login/logout
- Firebase-backed users
- Real-time Firestore community chat
- Send messages
- Persistent Firebase login session
- Android package: `com.chatwave.app`

## Firebase
The supplied Firebase Android configuration is already matched to the Android package used by this project. Before production, configure Firebase Authentication (Email/Password) and Firestore rules in the Firebase console.

## Run/build
Install Node.js, then:

    npm install
    npx expo start

For a local Android build you need the Android SDK/Gradle environment:

    npx expo prebuild --platform android
    npx expo run:android

An APK can also be produced with an Expo/EAS build environment.

## Important
This is a WhatsApp-style interface, not WhatsApp's proprietary code, branding, or assets.
