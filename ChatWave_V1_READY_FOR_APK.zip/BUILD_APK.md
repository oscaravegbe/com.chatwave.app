# ChatWave — Build the Android APK

This project is prepared for an EAS cloud build.

## 1. Install dependencies
npm install

## 2. Log in to Expo
npx eas-cli login

## 3. Configure/link the EAS project (first build only)
npx eas-cli build:configure

If prompted for an Android application identifier, use:
com.chatwave.app

## 4. Build an installable APK
npx eas-cli build --platform android --profile preview

The `preview` profile is configured to produce an APK. When the build finishes, EAS provides a build page/download URL. Open it on the Android phone and install the APK.

## Firebase setup
The supplied google-services.json is included in the project and the JavaScript Firebase configuration is already set for the ChatWave Firebase project.

Before real users use the app, enable:
- Authentication → Sign-in method → Email/Password
- Firestore Database

Also add production Firestore security rules before public launch.
