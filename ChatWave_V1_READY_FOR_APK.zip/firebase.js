import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyAv1GTEIgwPgT_6sjnlpT4zNxfp-MgeSjA',
  authDomain: 'chatwave-267c8.firebaseapp.com',
  projectId: 'chatwave-267c8',
  storageBucket: 'chatwave-267c8.firebasestorage.app',
  messagingSenderId: '565752083827',
  appId: '1:565752083827:android:c83ff496e20b6c55898106'
};

const app = initializeApp(firebaseConfig);
let auth;
try {
  auth = initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
} catch (_) {
  auth = getAuth(app);
}

export { auth, getFirestore };
export const db = getFirestore(app);
